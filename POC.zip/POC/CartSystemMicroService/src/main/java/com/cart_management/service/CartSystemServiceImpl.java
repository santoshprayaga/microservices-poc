package com.cart_management.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import com.cart_management.model.CartSystemResponse;

@Service
public class CartSystemServiceImpl implements CartSystemService {
	
	public static Map<String, Map<String, Integer>> cartMap = new HashMap<String, Map<String, Integer>>();

	@Override
	public CartSystemResponse addToCart(String userId, String item, Integer qty) {

		CartSystemResponse model = new CartSystemResponse();
		model.setUserId(userId);
		model.setItemName(item);
		model.setQuantity(qty);		
		if(cartMap.containsKey(userId)) {
			 Map<String, Integer> itemMap = cartMap.get(userId);
			 itemMap.put(item, qty);
		}else {
			Map<String, Integer> itemMap = new HashMap<>();
			 itemMap.put(item, qty);
			 cartMap.put(userId, itemMap);
		}
		model.setCartMap(cartMap);
		return model;
	}

	@Override
	public CartSystemResponse getCart(String userId) {
		CartSystemResponse model = new CartSystemResponse();
		model.setUserId(userId);
		Map<String, Map<String, Integer>> userCartMap = new HashMap<String, Map<String, Integer>>();
		userCartMap.put(userId, cartMap.get(userId));
		model.setCartMap(userCartMap);
		return model;
	}
}
