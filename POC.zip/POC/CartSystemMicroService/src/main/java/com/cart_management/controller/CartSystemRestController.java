package com.cart_management.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cart_management.model.CartSystemResponse;
import com.cart_management.service.CartSystemService;

@RestController
public class CartSystemRestController {

	@Autowired
	private CartSystemService service;

	@GetMapping(value = "addCart/{uId}/{item}/{qty}", produces = "application/json")
	public CartSystemResponse addToCart(@PathVariable("uId") String userId, @PathVariable("item") String item, @PathVariable("qty") Integer qty) {
		CartSystemResponse model = service.addToCart(userId, item, qty);
		return model;
	}
	
	@GetMapping(value = "getCart/{uId}", produces = "application/json")
	public CartSystemResponse addToCart(@PathVariable("uId") String userId) {
		CartSystemResponse model = service.getCart(userId);
		return model;
	}

	//Update Cart, Delete Cart

}