package com.cart_management.service;

import com.cart_management.model.CartSystemResponse;

public interface CartSystemService {

	public CartSystemResponse addToCart(String userId, String item, Integer qty);

	public CartSystemResponse getCart(String userId);

}
