package com.order_system.service;

import com.order_system.model.OrderSystemResponse;

public interface OrderSystemService {
	public OrderSystemResponse createOrder(String userId);
	
	
		
	}
	
	
	

