package com.order_system.service;

import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order_system.model.CartSystemResponse;
import com.order_system.model.OrderSystemResponse;

@Service
public class OrderSystemServiceImpl implements OrderSystemService {

	@Autowired
	private OrderSystemProxyClient proxyClient;

	@Override
	public OrderSystemResponse createOrder(String userId) {
		CartSystemResponse cart = proxyClient.getUserCart(userId);
		Map<String, Integer> userCartMap = cart.getCartMap().get(userId);
		OrderSystemResponse response = new OrderSystemResponse();
		response.setItemMap(userCartMap);
		int dc = 0;
		int ov = 0;
		int itemCount = 0;
		for(Entry<String, Integer> item : userCartMap.entrySet()) {
			itemCount++;
			switch (item.getKey()) {
			case "Idly":
				dc+=10;
				ov+=item.getValue()*20;
				break;
			case "Bonda":
				dc+=10;
				ov+=item.getValue()*20;
				break;
			case "Vada":
				dc+=10;
				ov+=item.getValue()*20;
				break;
			case "Dosa":
				dc+=10;
				ov+=item.getValue()*20;
				break;
			default:
				dc+=10;
				ov+=item.getValue()*20;
				break;
			}
		}
		response.setDeliveryCharge(dc/itemCount);
		response.setOrderValue(ov);
		response.setGst(new Double(response.getOrderValue()*5/100));
		response.setTotal(response.getDeliveryCharge()+response.getOrderValue()+response.getGst());
		
		return response;

	}
}