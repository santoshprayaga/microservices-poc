package com.order_system.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.order_system.model.CartSystemResponse;

@FeignClient(name = "CART-SYSTEM",url = "localhost:2000" )
public interface OrderSystemProxyClient {

	@GetMapping(value ="/getCart/{uId}" )
	public CartSystemResponse getUserCart(@PathVariable("uId") String userId);
			
}
