package com.order_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.order_system.model.OrderSystemResponse;
import com.order_system.service.OrderSystemService;

@RestController
public class OrderSystemRestController {

	@Autowired
	private OrderSystemService service;

	@GetMapping(value = "createOrder/{uId}", produces = "application/json")
	public OrderSystemResponse createOrder(@PathVariable("uId") String userId) {

		OrderSystemResponse response = service.createOrder(userId);
		return response;

	}

}
