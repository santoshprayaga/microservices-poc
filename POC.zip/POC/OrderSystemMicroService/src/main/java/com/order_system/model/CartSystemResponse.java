package com.order_system.model;

import java.util.Map;

import lombok.Data;

@Data
public class CartSystemResponse {
	
	private String userId;
	private String itemName;
	private Integer quantity;
	private Map<String, Map<String, Integer>> cartMap;

}
