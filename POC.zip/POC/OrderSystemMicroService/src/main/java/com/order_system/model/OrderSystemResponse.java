package com.order_system.model;

import java.util.Map;

import lombok.Data;

@Data
public class OrderSystemResponse {

	Map<String, Integer> itemMap;
	private Integer deliveryCharge;
	private Double gst;
	private Integer orderValue;
	private Double total;

}
